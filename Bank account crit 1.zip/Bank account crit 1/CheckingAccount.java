public class CheckingAccount extends BankAccount {
    private double interestRate;

    public CheckingAccount() {
        super();
        interestRate = 0;
    }

    public void processWithdrawal(double amount) {
        double overdraftFee = 30;
        double totalAmount = amount + overdraftFee;
        withdrawal(totalAmount);
        System.out.println("Withdrawal Amount: $" + amount);
        System.out.println("Overdraft Fee: $" + overdraftFee);
        System.out.println("Total Withdrawal Amount: $" + totalAmount);
    }

    public void displayAccount() {
        accountSummary();
        System.out.println("Interest Rate: " + interestRate + "%");
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }
}