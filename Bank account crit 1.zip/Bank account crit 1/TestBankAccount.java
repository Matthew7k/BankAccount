public class TestBankAccount {
    public static void main(String[] args) {
        BankAccount bankAccount = new BankAccount();
        bankAccount.setFirstName("Matt");
        bankAccount.setLastName("Petrillo");
        bankAccount.setAccountID(8675309);

        System.out.println("Bank Account Information:");
        bankAccount.accountSummary();

        bankAccount.deposit(1000);
        System.out.println("\nAfter deposit of $1000:");
        bankAccount.accountSummary();

        bankAccount.withdrawal(500);
        System.out.println("\nAfter withdrawal of $500:");
        bankAccount.accountSummary();

        System.out.println("\n=====================================\n");

        CheckingAccount checkingAccount = new CheckingAccount();
        checkingAccount.setFirstName("Chris");
        checkingAccount.setLastName("Petrillo");
        checkingAccount.setAccountID(123321);
        checkingAccount.setInterestRate(2.5);

        System.out.println("Checking Account Information:");
        checkingAccount.displayAccount();

        checkingAccount.deposit(2000);
        System.out.println("\nAfter deposit of $2000:");
        checkingAccount.displayAccount();

        checkingAccount.processWithdrawal(3000);
        System.out.println("\nAfter withdrawal of $3000:");
        checkingAccount.displayAccount();
    }
}